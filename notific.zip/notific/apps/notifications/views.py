from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from apps.notifications.serializers import NotificationSerializer
from apps.notifications.tasks import send_notification_task
from apps.notifications.models import Notification
from django.contrib.auth import get_user_model

User = get_user_model()

class SendNotificationView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        serializer = NotificationSerializer(data=request.data)
        if serializer.is_valid():
            # Создаем уведомление в БД
            try:
                user = User.objects.get(id=serializer.validated_data['user_id'])
            except User.DoesNotExist:
                return Response({"user_id": "User with this ID does not exist."}, status=status.HTTP_400_BAD_REQUEST)

            notification = Notification.objects.create(
                user=user,
                type=serializer.validated_data['type'],
                title=serializer.validated_data['title'],
                message=serializer.validated_data['message'],
                channels_priority=serializer.validated_data['channels_priority']
            )
            send_notification_task.delay(notification.id)
            return Response({"status": "accepted", "notification_id": notification.id}, status=status.HTTP_202_ACCEPTED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)