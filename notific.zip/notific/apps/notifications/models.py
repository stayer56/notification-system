from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class Notification(models.Model):
    NOTIFICATION_TYPES = (
        ('transactional', 'Транзакционное'),
        ('promotional', 'Промоционное'),
        ('security', 'Безопасность'),
    )
    
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    title = models.CharField(max_length=200)
    message = models.TextField()
    channels_priority = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, default='pending')

    def __str__(self):
        return f"Notification for {self.user.username} - {self.title}"

class DeliveryAttempt(models.Model):
    CHANNELS = (
        ('email', 'Email'),
        ('sms', 'SMS'),
        ('telegram', 'Telegram'),
    )
    
    notification = models.ForeignKey(Notification, on_delete=models.CASCADE)
    channel = models.CharField(max_length=10, choices=CHANNELS)
    attempted_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20)  # success, failed
    error_message = models.TextField(blank=True, null=True)

    def __str__(self):
        return f"Attempt for {self.notification.title} via {self.channel} - {self.status}"