from django.contrib import admin
from .models import Notification, DeliveryAttempt

@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'type', 'title', 'status', 'created_at')
    list_filter = ('type', 'status', 'channels_priority')
    search_fields = ('title', 'message', 'user__username')
    date_hierarchy = 'created_at'
    readonly_fields = ('created_at',)

@admin.register(DeliveryAttempt)
class DeliveryAttemptAdmin(admin.ModelAdmin):
    list_display = ('id', 'notification', 'channel', 'status', 'attempted_at')
    list_filter = ('channel', 'status')
    search_fields = ('notification__title', 'error_message')
    date_hierarchy = 'attempted_at'
    readonly_fields = ('attempted_at',)