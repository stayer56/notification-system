from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.html import strip_tags
import logging
import os

logger = logging.getLogger(__name__)

class EmailService:
    @staticmethod
    def send(notification):
        try:
            subject = notification.title
            context = {'notification': notification}
            html_message = render_to_string('notifications/email_notification.html', context)
            plain_message = strip_tags(html_message)
            from_email = os.getenv('EMAIL_HOST_USER')
            recipient_list = [notification.user.email] # Предполагаем, что у пользователя есть email
            
            send_mail(subject, plain_message, from_email, recipient_list, html_message=html_message)
            logger.info(f"Email sent to {notification.user.email} for notification {notification.id}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email for notification {notification.id}: {e}")
            return False

class SMSService:
    @staticmethod
    def send(notification):
        # Здесь будет логика отправки SMS через провайдера
        # Например, использование библиотеки requests для вызова API провайдера
        logger.info(f"SMS sending simulated for notification {notification.id}")
        return True # Заглушка

class TelegramService:
    @staticmethod
    def send(notification):
        # Здесь будет логика отправки сообщения в Telegram
        # Например, использование python-telegram-bot
        logger.info(f"Telegram message sending simulated for notification {notification.id}")
        return True # Заглушка
