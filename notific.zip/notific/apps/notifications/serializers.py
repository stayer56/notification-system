from rest_framework import serializers
from apps.notifications.models import Notification, DeliveryAttempt

class NotificationSerializer(serializers.Serializer):
    user_id = serializers.IntegerField()
    type = serializers.ChoiceField(choices=Notification.NOTIFICATION_TYPES)
    title = serializers.CharField(max_length=200)
    message = serializers.CharField()
    channels_priority = serializers.ListField(
        child=serializers.ChoiceField(choices=DeliveryAttempt.CHANNELS)
    )
