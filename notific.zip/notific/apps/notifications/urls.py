from django.urls import path
from apps.notifications.views import SendNotificationView

urlpatterns = [
    path('send/', SendNotificationView.as_view(), name='send_notification'),
]
