from celery import shared_task
from apps.notifications.models import Notification, DeliveryAttempt
from apps.notifications.services import EmailService, SMSService, TelegramService
from django.contrib.auth import get_user_model

User = get_user_model()

@shared_task(bind=True, max_retries=3)
def send_notification_task(self, notification_id):
    try:
        notification = Notification.objects.get(id=notification_id)
    except Notification.DoesNotExist:
        print(f"Notification with id {notification_id} not found.")
        return

    for channel in notification.channels_priority:
        try:
            success = False
            if channel == 'email':
                success = EmailService.send(notification)
            elif channel == 'sms':
                success = SMSService.send(notification)
            elif channel == 'telegram':
                success = TelegramService.send(notification)
            
            DeliveryAttempt.objects.create(
                notification=notification,
                channel=channel,
                status='success' if success else 'failed'
            )
            
            if success:
                notification.status = 'delivered'
                notification.save()
                return
                
        except Exception as exc:
            DeliveryAttempt.objects.create(
                notification=notification,
                channel=channel,
                status='failed',
                error_message=str(exc)
            )
            self.retry(exc=exc, countdown=2 ** self.request.retries)
            continue
    
    notification.status = 'failed'
    notification.save()

@shared_task
def send_email(notification_id):
    try:
        notification = Notification.objects.get(id=notification_id)
        return EmailService.send(notification)
    except Notification.DoesNotExist:
        print(f"Notification with id {notification_id} not found for email.")
        return False

@shared_task
def send_sms(notification_id):
    try:
        notification = Notification.objects.get(id=notification_id)
        return SMSService.send(notification)
    except Notification.DoesNotExist:
        print(f"Notification with id {notification_id} not found for sms.")
        return False

@shared_task
def send_telegram(notification_id):
    try:
        notification = Notification.objects.get(id=notification_id)
        return TelegramService.send(notification)
    except Notification.DoesNotExist:
        print(f"Notification with id {notification_id} not found for telegram.")
        return False
