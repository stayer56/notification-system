from django.urls import path
from apps.analytics.views import NotificationStatsView

urlpatterns = [
    path('stats/', NotificationStatsView.as_view(), name='notification_stats'),
]
