from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from apps.analytics.services import NotificationAnalytics

class NotificationStatsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        stats = NotificationAnalytics.get_delivery_stats()
        return Response(stats, status=status.HTTP_200_OK)