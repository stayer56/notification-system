from django.db.models import Count, Q
from apps.notifications.models import Notification, DeliveryAttempt

class NotificationAnalytics:
    @staticmethod
    def get_delivery_stats():
        return {
            'total': Notification.objects.count(),
            'delivered': Notification.objects.filter(status='delivered').count(),
            'failed': Notification.objects.filter(status='failed').count(),
            'by_channel': DeliveryAttempt.objects.values('channel')
                                .annotate(count=Count('id'))
                                .annotate(success=Count('id', filter=Q(status='success')))
        }
